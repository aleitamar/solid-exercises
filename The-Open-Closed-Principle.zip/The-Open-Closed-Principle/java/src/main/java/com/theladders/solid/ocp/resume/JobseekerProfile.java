package com.theladders.solid.ocp.resume;

public class JobseekerProfile
{
  private int id;

  public JobseekerProfile(int id)
  {
    this.id = id;
  }

  public int getId()
  {
    return id;
  }
}

package com.theladders.solid.ocp.jobseeker;


public class JobseekerConfidentialityProfileDao
{
  public JobseekerConfidentialityProfile fetchJobSeekerConfidentialityProfile(int id)
  {
    return new JobseekerConfidentialityProfile();
  }
}
